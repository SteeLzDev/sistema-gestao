package com.oficina;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemaGestaoApplicationTests {

	@Test
	void contextLoads() {
	}

}
