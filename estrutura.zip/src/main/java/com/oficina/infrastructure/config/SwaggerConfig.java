package com.oficina.infrastructure.config;

public class SwaggerConfig {
}
