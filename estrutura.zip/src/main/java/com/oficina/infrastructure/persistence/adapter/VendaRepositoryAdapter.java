package com.oficina.infrastructure.persistence.adapter;

public class VendaRepositoryAdapter {
}
