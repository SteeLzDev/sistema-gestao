package com.oficina.infrastructure.persistence.entity;

public class ProdutoEntity {
}
