package com.oficina.infrastructure.rest.dto;

public class ClienteDTO {
}
