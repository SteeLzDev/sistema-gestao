package com.oficina.infrastructure.rest.dto;

public class UsuarioDTO {
}
