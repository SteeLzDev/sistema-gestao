package com.oficina.infrastructure.rest.dto;

import java.time.LocalDateTime;

/**
 * DTO para cliente na fila de atendimento
 */
public class ClienteFilaDTO {
    private Long id;
    private String nome;
    private String servico;
    private String status;
    private LocalDateTime chegada;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getServico() {
        return servico;
    }

    public void setServico(String servico) {
        this.servico = servico;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDateTime getChegada() {
        return chegada;
    }

    public void setChegada(LocalDateTime chegada) {
        this.chegada = chegada;
    }
}

